<?php

namespace App\Livewire;

use Livewire\Component;

class CkTextEditor extends Component
{
    public function render()
    {
        return view('livewire.ck-text-editor');
    }
}
