<div>
    <button type="button" wire:click="logout" class="btn btn-danger d-flex">
        <small class="align-middle">Logout</small>
        <i class="ri-logout-box-r-line ms-2 ri-16px"></i>
    </button>
    
</div>
